---
name: Aura
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#F5F2F0'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1A1A1A'
  on-surface-variant: '#524343'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#847373'
  outline-variant: '#d6c2c2'
  surface-tint: '#854f51'
  primary: '#824c4e'
  on-primary: '#ffffff'
  primary-container: '#9e6466'
  on-primary-container: '#fffaf9'
  inverse-primary: '#fab5b6'
  secondary: '#5e604b'
  on-secondary: '#ffffff'
  secondary-container: '#e0e2c7'
  on-secondary-container: '#62644f'
  tertiary: '#70573e'
  on-tertiary: '#ffffff'
  tertiary-container: '#8a6f55'
  on-tertiary-container: '#fffbfa'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#fab5b6'
  on-primary-fixed: '#350e12'
  on-primary-fixed-variant: '#6a383b'
  secondary-fixed: '#e3e4ca'
  secondary-fixed-dim: '#c7c8af'
  on-secondary-fixed: '#1b1d0d'
  on-secondary-fixed-variant: '#464835'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#e2c0a2'
  on-tertiary-fixed: '#291805'
  on-tertiary-fixed-variant: '#59422b'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  accent-rose: '#7B5455'
typography:
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 26px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-mobile: 1rem
  margin-desktop: 2.5rem
  gutter: 1rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 2rem
---

## Brand & Style

The design system embodies an **Elegant Modern** aesthetic, pivoting towards a more sophisticated and high-contrast version of its predecessor. By shifting the foundation to pure white and deepening the signature pink and beige tones, the brand moves from "soft pastel" to "refined luxury." The target audience remains discerning and style-conscious, but the UI now evokes a stronger sense of confidence and visual depth.

The style is rooted in **Minimalism** with **Modern Corporate** precision. It leverages heavy whitespace and a restricted, high-quality color palette to ensure that content—particularly high-end product photography—remains the focus. The interaction model is calm and deliberate, using saturated accents to guide the eye without overwhelming the senses.

## Colors

The color strategy has been updated to provide greater saturation and visual authority against a stark white backdrop.
- **Primary (#9E6466):** A darkened, rich rosewood evolved from the original baby pink. It is used for primary actions and brand-critical touchpoints.
- **Secondary (#8B8D76):** An earthy, saturated sage-beige that provides a grounded counterpoint to the primary pink.
- **Tertiary (#D9B89A):** A warm, deep almond used for decorative containers and subtle highlights.
- **Surface (#FFFFFF):** A pure white base that maximizes clarity and modernizes the interface.

Functional containers now utilize the richer secondary and tertiary tones to create "islands" of content, ensuring that the "elegant feel" is maintained through sophisticated color harmony rather than low contrast.

## Typography

To ensure legibility against the pure white background, typography weights have been slightly adjusted for better "ink" presence. 
- **Be Vietnam Pro** (Headlines/Labels) provides a contemporary, geometric elegance. Headlines use tighter line-heights to feel more like editorial titles.
- **IBM Plex Sans** (Body) offers a systematic clarity for descriptions and long-form content. 

Text colors default to a deep off-black (`#1A1A1A`) to avoid the harshness of pure black while maintaining maximum accessibility. For Arabic script support, increase the line-height by approximately 15% across all levels to accommodate ascenders and descenders.

## Layout & Spacing

The layout utilizes a **Fluid Grid** system that prioritizes generous margins to reinforce the premium brand feel.
- **Mobile (Up to 600px):** 4-column grid with 16px (1rem) margins. Components like product tiles typically span 2 columns.
- **Tablet (601px - 1024px):** 8-column grid with 24px margins.
- **Desktop (1025px+):** 12-column grid with a max-width of 1440px and 40px (2.5rem) margins.

Spacing follows an 8px base scale. Use `stack-lg` for separating major sections (e.g., Hero from Product Grid) and `stack-md` for internal component spacing (e.g., Title from Body text).

## Elevation & Depth

With the transition to a pure white surface, hierarchy is now established through **Tonal Layers** and **Ambient Shadows**:
- **Layer 1 (Surface):** Pure White (#FFFFFF).
- **Layer 2 (Containers):** Softly tinted backgrounds using the secondary or tertiary colors at very low opacities, or light gray (#F5F2F0) to define sections without borders.
- **Shadows:** Use a "Natural Lift" for cards and modals. Shadows should be diffused and slightly tinted with the primary rose color to maintain warmth: `0px 10px 30px rgba(158, 100, 102, 0.08)`.
- **Active States:** Elements like pressed buttons or active navigation items should use a subtle inset shadow or a shift in saturation to provide tactile feedback.

## Shapes

The shape language is **Rounded**, balancing the clean lines of the typography with a soft, approachable feel.
- **Components:** Standard buttons, input fields, and small cards use a 0.5rem (8px) radius.
- **Large Containers:** Hero sections or large layout blocks use `rounded-xl` (1.5rem) to create a distinct framing effect.
- **Interactive Elements:** Iconic elements like category filters or "Quick Add" buttons should remain fully rounded (pill-shaped) to distinguish them from structural content containers.

## Components

### Buttons
Primary buttons are solid Saturated Rose (#9E6466) with White text. Secondary buttons use an outlined style with the Rose border or a solid Sage-Beige (#8B8D76) background. Both feature a 0.5rem radius and high-contrast text.

### Input Fields
Inputs are White with a 1px border in the secondary color. On focus, the border thickens to 2px and shifts to the primary color. Labels are placed in `label-sm` with a slight uppercase styling for a premium look.

### Cards
Product cards utilize the "Natural Lift" shadow on the white background. The bottom section of the card, containing the price and title, may use a subtle beige background to separate the product metadata from the imagery.

### Navigation
The Navigation Bar is pure White with a thin, low-contrast bottom border. Active states are indicated by a saturated Primary Rose underline or icon tint.

### Chips & Tags
Use pill-shaped containers for status tags (e.g., "New," "Limited Edition"). Use the Tertiary almond color for these tags to provide a distinct look that doesn't compete with primary action buttons.